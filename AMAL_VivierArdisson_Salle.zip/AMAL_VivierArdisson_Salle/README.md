# APD_AMAL
Article APD: https://openreview.net/forum?id=nubKjBbazd  
pdf: https://openreview.net/pdf?id=nubKjBbazd

librarie CAM++: https://github.com/jacobgil/pytorch-grad-cam

inception-v4: https://huggingface.co/docs/timm/en/models/inception-v4
