# https://github.com/lukemelas/PyTorch-Pretrained-ViT

# pip install pytorch_pretrained_vit

# how to use:
from pytorch_pretrained_vit import ViT
model = ViT('B_16_imagenet1k', pretrained=True)